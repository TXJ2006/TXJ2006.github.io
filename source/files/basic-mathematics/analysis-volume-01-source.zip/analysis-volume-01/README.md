# 分析学讲义·第一册：实数基础配图修订

修订日期：2026 年 11 月 1 日。

## 阅读文件

- `main.pdf`：完整第一册，共 254 个 PDF 页面，保留全部二十九章。
- `real-number-foundations.pdf`：第一至四章节选，共 58 页，保留原正文页码与本范围内的目录书签。

本轮在前四章新增七幅图，补充上、下界与确界、任意误差刻画、有理缺口、分割的无限并与交、Cauchy 尾部和单调收敛的说明。图解与相邻的量词、端点和存在性解释同步修改。后续章节未作内容修订。网站发布所用的 PDF 与源码包均采用本配图修订版（2026 年 11 月 5 日更新）。

## 源文件

正文入口为 `main.tex`，章节位于 `chapters/`。七幅新图的独立 TikZ 源码和已编译 PDF 位于 `figures/`，统一样式为 `figures/style.tex`，正文引用宏为 `figures/latex_includes.tex`。

需要 Tectonic 及其可用的 TeX 包缓存或下载连接。先进入 `figures/`，重新生成图件：

```sh
for source in tikz_*.tex; do
  tectonic -X compile --keep-logs "$source" || exit 1
done
```

再回到本目录编译整册：

```sh
tectonic -X compile --keep-logs --keep-intermediates main.tex
```

图件未改动时，直接编译 `main.tex` 即可。节选是从整册导出的阅读副本，不是独立的 TeX 入口。

## 核验范围

整册编译通过，日志无未定义引用、缺字、重复标签或盒子溢出。已逐张检查七幅新图，并打开最终整册中各图所在页及相邻页核对排版。具体记录见 `review/实数基础配图记录.md`。这次核验不代表重新审校了全部二十九章的每个证明。

## 网站发布文件

网站沿用 `analysis-volume-01.pdf` 与 `analysis-volume-01-source.zip` 的原下载地址。源码包保留正文、全部章节、七幅新图的 TikZ 源码及图件 PDF，以及历次审校记录；不包含可由编译重新生成的整册 PDF、节选 PDF 和辅助日志。整册 PDF 请从网站单独下载，节选为本地阅读副本。审校记录中的“尚未发布”描述的是 2026 年 11 月 1 日的本地交付状态。
