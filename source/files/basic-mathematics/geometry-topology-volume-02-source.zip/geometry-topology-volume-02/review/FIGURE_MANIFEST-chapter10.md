# 第十章图件计划

状态：ready。单章续写，沿用数学构造的 TikZ 矢量图，不需要论文流程图。
正文宽156 mm，四图实际包含宽132.6 mm。原生宽约110–130 mm，图源正文9–10 pt，页内预计9.2–12 pt。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_hyperbolic_halfplane | claim=上半平面测地线为竖线或与实轴正交的半圆，实轴不属于空间 | source=chapters/10-hyperbolic-plane-surfaces.tex | section=距离与测地线 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_hyperbolic_disk_triangle | claim=圆盘测地三角形由正交圆弧组成，欧氏外观与双曲角面积不同 | source=chapters/10-hyperbolic-plane-surfaces.tex | section=圆盘模型与角度 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_hyperbolic_regular_octagon | claim=正双曲八边形对边等距配对，每角π/4时商顶点总角2π | source=chapters/10-hyperbolic-plane-surfaces.tex | section=闭曲面的双曲多边形构造 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_hyperbolic_ideal_triangle | claim=理想三角形顶点在无穷远边界，区域非紧但面积有限 | source=chapters/10-hyperbolic-plane-surfaces.tex | section=理想三角形与面积积分 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=4, ILLUSTRATION=0, OPTIONAL=0, ALL=4
<!-- END FIGURE_MANIFEST -->

执行顺序：上半平面测地线、圆盘三角形、正八边形、理想三角形。
几何坐标由正交圆方程与正文公式计算，长解释留在正文。

交付对账：4幅图均有tex与pdf；4个包含宏均在正文调用一次；尺寸审计4/4 PASS。独立图件与PDF第88–104页已打开检查，无严重缺失、遮挡或裁切。复核记录见chapter10-hyperbolic-plane-surfaces.md。
