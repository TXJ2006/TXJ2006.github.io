# 第八章覆盖空间图件计划

状态：ready。延续确定性 TikZ 矢量图；正文宽 156 mm。
圆周图原生宽约 90 mm，子格图原生宽约 120 mm；源正文字号 9 pt。
预定包含宽 0.85 textwidth，最终按实际尺寸和页面核验；图注及正文为中文。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_covering_circle | claim=整数点在同一纤维且一圈提升从0到1 | source=chapters/08-covering-spaces.tex | section=圆周覆盖与环面覆盖 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_torus_cover | claim=L由差为偶数的格点组成且基本平行四边形面积为2 | source=chapters/08-covering-spaces.tex | section=环面的平面覆盖 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=2, ILLUSTRATION=0, OPTIONAL=0, ALL=2
<!-- END FIGURE_MANIFEST -->

执行顺序：圆周覆盖 → 环面子格。

## 最终交付核验（2026-11-02）

- tikz_covering_circle：figures/tikz_covering_circle.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 12.89 pt，尺寸审计 PASS；独立图像与最终页面均已查看。
- tikz_torus_cover：figures/tikz_torus_cover.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 9.4 pt，尺寸审计 PASS；独立图像与最终页面均已查看。

全部包含宏在正文各调用一次，且各包含唯一 PDF。最终本轮七图均通过尺寸审计，无标签遮挡、错误端点或裁切。自动 TikZ 检查 0 CRITICAL；原生 grep 不支持 -P 导致部分启发式未执行，以实际图像审查补足，不据脚本结果声称全面通过。
