# 第十三章图件计划

状态：ready。四幅TikZ图，实际包含宽132.6mm。

- tikz_pants_decomposition：裤分解后的裤面与切口
- tikz_pants_hexagon：直角六边形与缝线公式
- tikz_twist_gluing：等长边界的扭转粘合
- tikz_fn_coordinates：Fenchel–Nielsen长度与扭转坐标

四项均有tex、pdf、正文宏和一次正文调用；尺寸审计与TikZ检查记录见chapter13-figure-size.json、chapter13-tikz-check.txt。
