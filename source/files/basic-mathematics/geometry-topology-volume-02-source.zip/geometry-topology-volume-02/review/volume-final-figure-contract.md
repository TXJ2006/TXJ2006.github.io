# 第三章图件修复清单

状态：ready（内部复核候选稿）；仅修复审查发现的三幅既有几何图。原始版本备份在 work/geometry-v2-final-review/before/figures。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_polygon_words | claim=同名箭头识别与逆时针边词的对应 | source=chapters/03-polygon-gluings.tex | section=3.1 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_torus_cell | claim=环面的一维骨架与二维胞腔附着 | source=chapters/03-polygon-gluings.tex | section=3.3.1 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_orientation | claim=比较粘合后两侧诱导的边界方向 | source=chapters/03-polygon-gluings.tex | section=3.5 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=3, ILLUSTRATION=0, OPTIONAL=0, ALL=3
<!-- END FIGURE_MANIFEST -->

三个图分别比较同一概念的模型、展示胞腔附着、对照方向判据；不新增装饰图。数学文字保持黑色，保留本章灰色线稿风格。

## 最终对账

三幅图的TeX/PDF均已生成；沿用宏名和图号，无缺失。包含宽度由实际长宽比规整为0.85\\textwidth，最终宽132.6mm；正文直接调用同一宏，未另行改写尺寸。三图已分别完整查看，并检查最终正文PDF第28、31、33页；未见标注遮挡或裁切。字号结果见volume-final-figure-size.json。

图3.1及3.4统一规定：同名箭头表示识别参数方向，从左下角起沿边界逆时针读字，顺箭头为正，逆箭头为负。环面读aba⁻¹b⁻¹，克莱因瓶读aba⁻¹b；射影平面的上下弧连读aa。图3.3右侧只表示一维骨架，并明确另附加二维胞腔，不把圆环画成整个环面。

不重新运行无关的全图集绘制；只保留本轮三图的差异记录、编译检查和尺寸结果。启发式TikZ检查的grep兼容性限制已在总审查记录注明。
