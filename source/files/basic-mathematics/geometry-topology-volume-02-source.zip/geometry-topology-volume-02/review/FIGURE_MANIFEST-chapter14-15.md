# 第十四、十五章与第十三章图件修正计划

全部是由明确模型生成的数学示意图，不使用实验数据或AI场景图。
新增8幅，替换3幅；正文目标宽132.6mm，独立图使用10pt标注。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_geodesic_flow_state | claim=位置与方向共同确定状态 | source=chapters/14-geodesic-flow-dynamics.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_jacobi_splitting | claim=Jacobi相平面两条特征线 | source=chapters/14-geodesic-flow-dynamics.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_horocycle_stable | claim=同相位竖直线的双曲距离收缩 | source=chapters/14-geodesic-flow-dynamics.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_recurrence_distinction | claim=周期与复现定义不同 | source=chapters/14-geodesic-flow-dynamics.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_tangent_cotangent | claim=微分是作用于切向量的泛函 | source=chapters/15-smooth-surfaces-degree-index.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_transversality | claim=横截相交与相切的导数差别 | source=chapters/15-smooth-surfaces-degree-index.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_degree_local_signs | claim=局部度按定向符号相加 | source=chapters/15-smooth-surfaces-degree-index.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_vector_field_index | claim=沿圆周直接计算方向绕数 | source=chapters/15-smooth-surfaces-degree-index.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_pants_decomposition | claim=裤面有三个真实边界分支 | source=chapters/13-pants-fenchel-nielsen.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_twist_gluing | claim=圆周位移不能记住整圈数 | source=chapters/13-pants-fenchel-nielsen.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_pants_hexagon | claim=保角圆盘中的真实直角六边形 | source=chapters/13-pants-fenchel-nielsen.tex | section=正文对应小节 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=11, ILLUSTRATION=0, OPTIONAL=0, ALL=11
<!-- END FIGURE_MANIFEST -->

执行顺序：测地流四图、光滑曲面四图、裤面三幅修正。逐图编译并按最终包含尺寸检查。
