# 第九章图件计划与核验

状态：ready。续写单章，不是完整论文图集。沿用精确 TikZ 矢量图；不画研究路线图。
正文宽 156 mm，目标包含宽 132.6 mm；图源宽约 110–130 mm、正文 9–10 pt，预期页内正文约 9.2–12 pt。
先生成和查看四图，再写入正文；长说明与证明放正文。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_cone_angle_defect | claim=顶点邻域剪开为总角θ的扇形，缺角K等于2π−θ | source=chapters/09-polyhedral-metrics-curvature.tex | section=圆锥角与角亏 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_geodesic_unfolding | claim=跨过普通内边的局部最短路在两三角形展开后为直线 | source=chapters/09-polyhedral-metrics-curvature.tex | section=最短路与展开 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_boundary_turning | claim=凹边界顶点内角超过π，外转角为负，扇形计角给出边界项 | source=chapters/09-polyhedral-metrics-curvature.tex | section=带边界的离散Gauss–Bonnet | language=zh | format=tex,pdf | layout=single-landscape
- tikz_octagon_cone_surface | claim=正八边形对边平移粘合为亏格二曲面且八角归于同一顶点 | source=chapters/09-polyhedral-metrics-curvature.tex | section=亏格二八边形模型 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=4, ILLUSTRATION=0, OPTIONAL=0, ALL=4
<!-- END FIGURE_MANIFEST -->

执行顺序：圆锥角 → 过边展开 → 边界转角 → 八边形模型。

## 最终对账（2026-11-02）

- tikz_cone_angle_defect：figures/tikz_cone_angle_defect.tex 与 .pdf 均存在；包含宽 132.6 mm，字号中位数 10.87 pt，尺寸 PASS。图件独立渲染及最终正文页面均已实际查看；无严重遮挡或裁切。
- tikz_geodesic_unfolding：figures/tikz_geodesic_unfolding.tex 与 .pdf 均存在；包含宽 132.6 mm，字号中位数 10.81 pt，尺寸 PASS。图件独立渲染及最终正文页面均已实际查看；无严重遮挡或裁切。
- tikz_boundary_turning：figures/tikz_boundary_turning.tex 与 .pdf 均存在；包含宽 132.6 mm，字号中位数 12.58 pt，尺寸 PASS。图件独立渲染及最终正文页面均已实际查看；无严重遮挡或裁切。
- tikz_octagon_cone_surface：figures/tikz_octagon_cone_surface.tex 与 .pdf 均存在；包含宽 132.6 mm，字号中位数 10.32 pt，尺寸 PASS。图件独立渲染及最终正文页面均已实际查看；无严重遮挡或裁切。

四宏与归一化包含片段精确对账，均在第九章各调用一次。最终89页、九章、30图。TikZ检查0 CRITICAL；grep -P的系统兼容限制另记README。
