# 第十一章图件计划

状态：ready。继续曲面几何主线，四幅精确构造图；无数据图或流程图需求。
正文宽156mm，实际包含宽132.6mm，图源宽约110–130mm，正文标注9pt以上。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_geodesic_axis | claim=双曲伸缩的最小位移在轴上取得，垂距控制轴外位移 | source=chapters/11-closed-geodesics-length.tex | section=轴与平移长度 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_hyperbolic_cylinder | claim=沿轴周期识别给出双曲圆柱，等距曲线长度按cosh变化 | source=chapters/11-closed-geodesics-length.tex | section=双曲圆柱与法向坐标 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_parabolic_cusp | claim=抛物平移商的尖端面积有限但闭路长度下确界不取得 | source=chapters/11-closed-geodesics-length.tex | section=非紧尖端与紧致性的作用 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_injectivity_midpoint | claim=相邻提升点间的中点解释注入半径的二分之一因子 | source=chapters/11-closed-geodesics-length.tex | section=注入半径与最短闭测地线 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=4, ILLUSTRATION=0, OPTIONAL=0, ALL=4
<!-- END FIGURE_MANIFEST -->

执行顺序：轴、圆柱、尖端、注入半径。所有弧按模型测地线或等距曲线方程生成，图中文字保持简短。

交付对账：四幅图均有tex和pdf；四宏正文各调用一次，与归一化片段完全一致。包含宽132.6mm，字号审计4/4 PASS。独立图件及最终正文页面均已打开查看，无严重缺失、遮挡或裁切。圆柱图完成两轮文字位置修复后停止。
