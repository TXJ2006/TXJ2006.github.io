# 第十二章图件计划

状态：ready。继续曲面的双曲几何；四幅精确TikZ图，无数据图或流程图需求。
正文宽156mm，实际包含宽132.6mm；独立图件标注采用9pt上下，目标原生宽约110–130mm。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_ultraparallel_axes | claim=不相交且不共理想端点的轴可由唯一公共垂线规范化，轴距由矩阵参数给出 | source=chapters/12-collars-intersections.tex | section=两条不相交轴的距离 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_collar_lifts | claim=同一简单闭测地线不同提升轴的间距下界保证开嵌入带不自重叠 | source=chapters/12-collars-intersections.tex | section=单条闭测地线的定量嵌入带 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_crossing_axes_angle | claim=相交轴的长度及夹角进入交换子迹公式，得到相交限制 | source=chapters/12-collars-intersections.tex | section=相交长度与夹角不等式 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_collar_crossing_arc | claim=穿过核心的测地弧必须横穿整个嵌入带，每次穿越至少花费两倍半宽 | source=chapters/12-collars-intersections.tex | section=交点数与长度代价 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=4, ILLUSTRATION=0, OPTIONAL=0, ALL=4
<!-- END FIGURE_MANIFEST -->

执行顺序：公共垂线、提升带、交角、横穿弧。图中几何按模型方程生成，长证明留在正文。

四项均已有tex、pdf及正文宏调用，各调用一次；包含片段、尺寸审计、TikZ检查和正文页面检查记录已保存。全部最终图在PDF第117、119、121、122页。字号中位9.62–12.03pt，尺寸检查PASS。原生grep不支持-P的检查边界见本章复核记录。
