# 第六章补充与第七章图件计划

状态：ready。路线为精确拓扑示意的 TikZ 矢量 PDF；正文宽 156 mm。
每图原生宽度约 110–130 mm、源正文字号 9 pt，按 0.85 倍正文宽包含时，
预计有效正文字号约 9–11 pt；具体值由编译后尺寸审计确定。
图示解释证明中的实际构造，不代替证明。

<!-- BEGIN FIGURE_MANIFEST -->
## 图表清单（FIGURE_MANIFEST）

**数据图（matplotlib；paper-figure）：**
- none

**DrawIO 确定性技术图（paper-technical-diagram）：**
- none

**TikZ 精确图（paper-technical-diagram）：**
- tikz_basepoint_motion | claim=同伦正方形的左右边都为基点轨迹h，给出f0*=βh f1* | source=chapters/06-paths-homotopy-fundamental-group.tex | section=基点移动与同伦等价 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_vankampen_grid | claim=每小格落在U或V，局部边界关系给出核的全部关系 | source=chapters/07-vankampen-surface-groups.tex | section=van Kampen定理的核 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_graph_tree_basis | claim=θ图的生成树留下一对自由生成元且E-V+1=2 | source=chapters/07-vankampen-surface-groups.tex | section=有限图的基本群 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_cell_attachment | claim=附加圆盘的开覆盖交为穿孔圆盘，故只杀掉附加词的正规闭包 | source=chapters/07-vankampen-surface-groups.tex | section=附加二维胞腔 | language=zh | format=tex,pdf | layout=single-landscape
- tikz_punctured_torus_boundary | claim=带一孔环面的边界代表交换子的逆且未封口前不平凡 | source=chapters/07-vankampen-surface-groups.tex | section=带边界曲面 | language=zh | format=tex,pdf | layout=single-landscape

**AI 场景图（paper-illustration）：**
- none

**显式可选格式（HTML / Mermaid）：**
- none

**总数：** DATA=0, DRAWIO=0, TIKZ=5, ILLUSTRATION=0, OPTIONAL=0, ALL=5
<!-- END FIGURE_MANIFEST -->

第六章补图 1 张，第七章新增 4 张。执行顺序按上列顺序。
完成后逐图记录源文件、PDF、实际页内包含尺寸与视觉检查结果。

## 最终交付核验（2026-11-02）

- tikz_basepoint_motion：figures/tikz_basepoint_motion.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 10.55 pt，尺寸审计 PASS；独立图像与最终页面均已查看。
- tikz_vankampen_grid：figures/tikz_vankampen_grid.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 10.56 pt，尺寸审计 PASS；独立图像与最终页面均已查看。
- tikz_graph_tree_basis：figures/tikz_graph_tree_basis.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 10.64 pt，尺寸审计 PASS；独立图像与最终页面均已查看。
- tikz_cell_attachment：figures/tikz_cell_attachment.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 11.35 pt，尺寸审计 PASS；独立图像与最终页面均已查看。
- tikz_punctured_torus_boundary：figures/tikz_punctured_torus_boundary.tex 与 .pdf 均已交付；包含宽 132.6 mm，页内正文字号中位数 11.39 pt，尺寸审计 PASS；独立图像与最终页面均已查看。

全部包含宏在正文各调用一次，且各包含唯一 PDF。最终本轮七图均通过尺寸审计，无标签遮挡、错误端点或裁切。自动 TikZ 检查 0 CRITICAL；原生 grep 不支持 -P 导致部分启发式未执行，以实际图像审查补足，不据脚本结果声称全面通过。
