from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# Adapted from Vivid Figures basic.line; the plot data are exact formulas.
OUTPUT_DIR = Path(__file__).resolve().parent
plt.rcParams.update(json.loads((OUTPUT_DIR / 'sine_plot_style.json').read_text()))
COLORS = {'grid': '#E0E0E0'}

# Exact mathematical input; phase sampling avoids aliasing near x=0.
t = np.unique(np.r_[np.linspace(1.0, 80.0, 10000), np.pi/2, 3*np.pi/2])[::-1]
x = 1.0 / t
series = {r'$G:\ y=\sin(1/x)$': np.sin(t)}
markers = ['']
# No statistical interval: this is a mathematical set, not uncertain estimates.
fig, ax = plt.subplots(figsize=(6.6, 3.5))

for i, (name, y) in enumerate(series.items()):
    is_ours = True

    # 主折线
    ax.plot(x, y, '-', color='black',
            linewidth=1.0, markersize=7 if is_ours else 5,
            markeredgecolor='white', markeredgewidth=1.2, label=name, zorder=3)

    # 极值标注（最大值）
    max_idx = np.argmin(np.abs(x - 2/np.pi))
    ax.scatter(x[max_idx], y[max_idx], s=38, color='black',
               edgecolor='white', linewidth=0.8, zorder=4, marker='o')
    if is_ours:
        ax.annotate(r'$(2/\pi,1)$',
                    xy=(x[max_idx], y[max_idx]),
                    xytext=(0.56, 1.23),
                    fontsize=11, color='black',
                    arrowprops=dict(arrowstyle='->', color='black', lw=1.2),
                    bbox=dict(boxstyle='round,pad=0.3', facecolor='white',
                              edgecolor='black', alpha=1))

# The added vertical segment is an exact closed set, drawn independently.
ax.plot([0, 0], [-1, 1], color='black', linewidth=2.0, label=r'$L=\{0\}\times[-1,1]$')
ax.scatter([0, 0, 1], [-1, 1, np.sin(1)], s=15, color='black', zorder=4)
ax.set_xlabel('$x$', fontsize=12)
ax.set_ylabel('$y$', fontsize=12, rotation=0, labelpad=8)
ax.legend(frameon=False, labelspacing=0.35, handlelength=1.6, fontsize=10, loc='lower right')
ax.set_xlim(-0.065, 1.04)
ax.set_ylim(-1.35, 1.5)
ax.set_xticks([0, .2, .4, .6, .8, 1])
ax.set_yticks([-1, 0, 1])
ax.tick_params(labelsize=11)
ax.axhline(0, color='0.65', linewidth=.5, zorder=0)
ax.grid(alpha=0.12, linestyle='--', color=COLORS['grid'])
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
fig.tight_layout()
fig.savefig(OUTPUT_DIR / 'fig_sine_closure.pdf', bbox_inches=None, pad_inches=0.15)
fig.savefig(OUTPUT_DIR / 'fig_sine_closure.png', dpi=260)
np.savez(OUTPUT_DIR / 'sine_exact_input.npz', t=t, x=x, y=np.sin(t))
