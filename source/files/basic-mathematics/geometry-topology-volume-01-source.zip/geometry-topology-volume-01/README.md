# 几何与拓扑讲义·第一册

2026-11-01 第一至八章阶段稿，共125页。第八章十节，27条定理类结论及对应证明，7幅矢量图；内容包括商拓扑、商映射、分离性、圆周、环面、莫比乌斯带、闭集压缩、附着空间和实射影空间。八章正文均已写成，仍保留阶段稿标记。

main.pdf 为本轮编译结果，main.tex 为主文件。

编译：在本目录运行 `tectonic -X compile --keep-logs --keep-intermediates main.tex`，或者用 Codex 内置 LaTeX 编辑器打开本目录。

figures/ 下保留图件源文件和预编译矢量PDF；正文直接使用这些PDF。正常编译讲义不需要 Python。

正弦图的可编辑脚本为 figures/gen_fig_sine_curve.py，样式记录在同目录的 sine_plot_style.json。安装 NumPy、Matplotlib 后运行 `python3 figures/gen_fig_sine_curve.py`，可重新生成图件及精确参数采样文件。其余四幅新增图均有独立 TikZ 源文件，可运行 `tectonic -X compile figures/文件名.tex` 重建。

第八章的七幅新增图均有独立 TikZ 源文件和预编译 PDF，包含片段为 figures/latex_includes_08.tex。

审校范围与记录见 review/ 下第六、七、八章的记录。源码包包含八章正文、所有图件源码与预编译图件，不包含 Python 虚拟环境或编译临时文件。
