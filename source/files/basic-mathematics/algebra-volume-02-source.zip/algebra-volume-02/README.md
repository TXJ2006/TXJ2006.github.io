# 代数学讲义·第二册：群的结构理论

九章审校版，2026-10-29。PDF共142物理页。

主文件：main.tex。九个chapters文件及正文实际引用的五组图件一并附上。未编入本册的旧素材不在此压缩包内。

编译：在本目录运行 `tectonic -X compile main.tex`，或使用支持ctexbook和Fandol字体的XeLaTeX工具链编译。图件附矢量PDF及TikZ源，正文可直接编译，无需先重编图件。首次使用Tectonic可能需联网下载TeX依赖。

审校说明、版本哈希和辅助算例报告附在review目录。有限计算不代替正文的一般证明。
